import binascii
import serial
from serial.tools import list_ports
import time


crc8tab = []
crc8tab = [
    0x00, 0xD5, 0x7F, 0xAA, 0xFE, 0x2B, 0x81, 0x54, 0x29, 0xFC, 0x56, 0x83, 0xD7, 0x02, 0xA8, 0x7D,
    0x52, 0x87, 0x2D, 0xF8, 0xAC, 0x79, 0xD3, 0x06, 0x7B, 0xAE, 0x04, 0xD1, 0x85, 0x50, 0xFA, 0x2F,
    0xA4, 0x71, 0xDB, 0x0E, 0x5A, 0x8F, 0x25, 0xF0, 0x8D, 0x58, 0xF2, 0x27, 0x73, 0xA6, 0x0C, 0xD9,
    0xF6, 0x23, 0x89, 0x5C, 0x08, 0xDD, 0x77, 0xA2, 0xDF, 0x0A, 0xA0, 0x75, 0x21, 0xF4, 0x5E, 0x8B,
    0x9D, 0x48, 0xE2, 0x37, 0x63, 0xB6, 0x1C, 0xC9, 0xB4, 0x61, 0xCB, 0x1E, 0x4A, 0x9F, 0x35, 0xE0,
    0xCF, 0x1A, 0xB0, 0x65, 0x31, 0xE4, 0x4E, 0x9B, 0xE6, 0x33, 0x99, 0x4C, 0x18, 0xCD, 0x67, 0xB2,
    0x39, 0xEC, 0x46, 0x93, 0xC7, 0x12, 0xB8, 0x6D, 0x10, 0xC5, 0x6F, 0xBA, 0xEE, 0x3B, 0x91, 0x44,
    0x6B, 0xBE, 0x14, 0xC1, 0x95, 0x40, 0xEA, 0x3F, 0x42, 0x97, 0x3D, 0xE8, 0xBC, 0x69, 0xC3, 0x16,
    0xEF, 0x3A, 0x90, 0x45, 0x11, 0xC4, 0x6E, 0xBB, 0xC6, 0x13, 0xB9, 0x6C, 0x38, 0xED, 0x47, 0x92,
    0xBD, 0x68, 0xC2, 0x17, 0x43, 0x96, 0x3C, 0xE9, 0x94, 0x41, 0xEB, 0x3E, 0x6A, 0xBF, 0x15, 0xC0,
    0x4B, 0x9E, 0x34, 0xE1, 0xB5, 0x60, 0xCA, 0x1F, 0x62, 0xB7, 0x1D, 0xC8, 0x9C, 0x49, 0xE3, 0x36,
    0x19, 0xCC, 0x66, 0xB3, 0xE7, 0x32, 0x98, 0x4D, 0x30, 0xE5, 0x4F, 0x9A, 0xCE, 0x1B, 0xB1, 0x64,
    0x72, 0xA7, 0x0D, 0xD8, 0x8C, 0x59, 0xF3, 0x26, 0x5B, 0x8E, 0x24, 0xF1, 0xA5, 0x70, 0xDA, 0x0F,
    0x20, 0xF5, 0x5F, 0x8A, 0xDE, 0x0B, 0xA1, 0x74, 0x09, 0xDC, 0x76, 0xA3, 0xF7, 0x22, 0x88, 0x5D,
    0xD6, 0x03, 0xA9, 0x7C, 0x28, 0xFD, 0x57, 0x82, 0xFF, 0x2A, 0x80, 0x55, 0x01, 0xD4, 0x7E, 0xAB,
    0x84, 0x51, 0xFB, 0x2E, 0x7A, 0xAF, 0x05, 0xD0, 0xAD, 0x78, 0xD2, 0x07, 0x53, 0x86, 0x2C, 0xF9]

uartRxsyncSize = 2
uartRxHeaderSize = 4
uartRxCrcSize = 1


class USBSerialLink:

    def __init__(self):
        self.isOpen = False
        self.portIsActive = False

    def scanUSBRfLink(self, serNumber = 1):
        comlist = list(list_ports.comports())
        self.PossbileComs=[]
        count=0
        for element in comlist:
            if 'Silicon Labs' in element.manufacturer:
                if serNumber == 2:
                    if '0002' in element.serial_number:
                        # save possible ports
                        self.PossbileComs.append(element.device)
                else:
                    # save possible ports
                    self.PossbileComs.append(element.device)

                count+=1
               
    def openPort(self, port):
        if port == '':
            self.isOpen = False
            return False

        try:
            self.ser = serial.Serial(str(port),57600,timeout=2)
        except:
            #return "True"
            self.isOpen = False
            return False
        
        print(str(self.ser)+ " is Open")
        print("USART Baud: " + "57600")
        self.isOpen = True

        return True

    def getPossibleComs(self):
        return self.PossbileComs

    def closePort(self):
        try:
            self.ser.close()  # close serial port     
        except:
            pass

        self.isOpen = False

    def isPortOpen(self):
        return self.isOpen

    def URSBRFLinkFlushBuff(self):
        self.ser.flushInput()

    def rxUSBRFLink(self,rxData, timeout): 
     
        if self.isOpen != True:
            return "close",0

        self.portIsActive = True
        
        syncWord = []
        count = 0
        
        try:
            while self.isOpen == True:
                snc = self.ser.read(1)
                if snc:
                    count+=1
                    syncWord.append((snc))
                    if (count>=uartRxsyncSize):
                        if ord(syncWord[count-uartRxsyncSize]) == 0xaa and ord(syncWord[count-(uartRxsyncSize-1)]) == 0xbb:
                            break  
                else:
                    self.portIsActive = False
                    return "timeout",0                                   
            
            # budeme cist zacatek headru
            header = []
            #rxCmd =self.ser.read(1)
            for i in range(uartRxHeaderSize):
                tmp = self.ser.read(1)
                if tmp:
                    header.append(tmp)
                else:
                    self.portIsActive = False
                    return "timeout",0
                
            #kontrola crc headeru
            crc=self.crc8(header,uartRxHeaderSize-1)
            crc=crc.to_bytes(1,'little')

            if crc != header[uartRxHeaderSize-1]:
                self.portIsActive = False
                return "crcHeaderFail",0

            #payload
            y_raw=[]
            sizeOfPayload = header[0]
            for i in range(ord(sizeOfPayload)+uartRxCrcSize):
                znak = self.ser.read(1)
                if znak:
                    y_raw.append((znak))
                else:
                    self.portIsActive = False
                    return "timeout",0
            
            allPacket = bytearray()
            syncWord = syncWord[count-uartRxsyncSize:]
            allPacket= syncWord+header+y_raw
            
            #kontrola CRC
            CRC=self.crc8(allPacket,len(allPacket)-1)
            Rxcrc1=y_raw[len(y_raw)-1]
            
            if CRC==ord(Rxcrc1):
                command = y_raw[0]
                #if ord(command) > 0 and ord(command) < 180:
                self.portIsActive = False
                return "answerOk",y_raw
                            
            else:
                self.portIsActive = False
                return "crcFail",0
        
        except:
            return "portLost",0

       

    def crc16(self, data : bytearray, offset , length):
        if data is None or offset < 0 or offset > len(data)- 1 and offset+length > len(data):
            return 0
        crc = 0xFFFF
        for i in range(0, length):
            crc ^= data[offset + i] #<< 8
            for j in range(0,8):
                if (crc & 0x1) > 0:
                    crc =(crc >> 1) ^ 0xA001
                else:
                    crc = crc >> 1
        return crc & 0xFFFF


    def crc8(self,data : bytearray, size):
        crc = 0
        for i in range(0,size):
            crc = crc8tab[crc ^ ord(data[i])]        
        return crc

    def listToByteArray(self,inputList):
            bytePacket = bytearray()
            for i in inputList:
                bytePacket+=i

            return bytePacket